package com.eglobal.bo.api.zip.service;

public interface  ConectMailService {

}
