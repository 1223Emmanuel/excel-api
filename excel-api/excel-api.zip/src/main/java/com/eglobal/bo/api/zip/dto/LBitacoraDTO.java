package com.eglobal.bo.api.zip.dto;


public class LBitacoraDTO {

	private String dpetnumctaclaro;
	private String dpetfetxn2;       
	private String dpetimpotran;      
	private String dpetnumaut;   
	private int dpetfolegl;     
	private String  cnegnumero;    
	private String ctipdocclave;
	private String cnegnombre;
	private String cnegcalle;
	private String cciunombre;
	private String cnegcolonia;
	private String cnegcodpos;
	private String cnegnumtel;
	private String cnegnomres;
	private String dpetnumcta;
	private String cnegplazoent;
	private String fhvennat;
	private String foliobancario;

	private byte[] imgimagen;

	public String getDpetnumctaclaro() {
		return dpetnumctaclaro;
	}

	public void setDpetnumctaclaro(String dpetnumctaclaro) {
		this.dpetnumctaclaro = dpetnumctaclaro;
	}

	public String getDpetfetxn2() {
		return dpetfetxn2;
	}

	public void setDpetfetxn2(String dpetfetxn2) {
		this.dpetfetxn2 = dpetfetxn2;
	}

	public String getDpetimpotran() {
		return dpetimpotran;
	}

	public void setDpetimpotran(String dpetimpotran) {
		this.dpetimpotran = dpetimpotran;
	}

	public String getDpetnumaut() {
		return dpetnumaut;
	}

	public void setDpetnumaut(String dpetnumaut) {
		this.dpetnumaut = dpetnumaut;
	}

	public int getDpetfolegl() {
		return dpetfolegl;
	}

	public void setDpetfolegl(int dpetfolegl) {
		this.dpetfolegl = dpetfolegl;
	}

	public String getCnegnumero() {
		return cnegnumero;
	}

	public void setCnegnumero(String cnegnumero) {
		this.cnegnumero = cnegnumero;
	}

	public String getCtipdocclave() {
		return ctipdocclave;
	}

	public void setCtipdocclave(String ctipdocclave) {
		this.ctipdocclave = ctipdocclave;
	}

	public String getCnegnombre() {
		return cnegnombre;
	}

	public void setCnegnombre(String cnegnombre) {
		this.cnegnombre = cnegnombre;
	}

	public String getCnegcalle() {
		return cnegcalle;
	}

	public void setCnegcalle(String cnegcalle) {
		this.cnegcalle = cnegcalle;
	}

	public String getCciunombre() {
		return cciunombre;
	}

	public void setCciunombre(String cciunombre) {
		this.cciunombre = cciunombre;
	}

	public String getCnegcolonia() {
		return cnegcolonia;
	}

	public void setCnegcolonia(String cnegcolonia) {
		this.cnegcolonia = cnegcolonia;
	}

	public String getCnegcodpos() {
		return cnegcodpos;
	}

	public void setCnegcodpos(String cnegcodpos) {
		this.cnegcodpos = cnegcodpos;
	}

	public String getCnegnumtel() {
		return cnegnumtel;
	}

	public void setCnegnumtel(String cnegnumtel) {
		this.cnegnumtel = cnegnumtel;
	}

	public String getCnegnomres() {
		return cnegnomres;
	}

	public void setCnegnomres(String cnegnomres) {
		this.cnegnomres = cnegnomres;
	}

	public String getDpetnumcta() {
		return dpetnumcta;
	}

	public void setDpetnumcta(String dpetnumcta) {
		this.dpetnumcta = dpetnumcta;
	}

	public String getCnegplazoent() {
		return cnegplazoent;
	}

	public void setCnegplazoent(String cnegplazoent) {
		this.cnegplazoent = cnegplazoent;
	}

	public String getFhvennat() {
		return fhvennat;
	}

	public void setFhvennat(String fhvennat) {
		this.fhvennat = fhvennat;
	}

	public String getFoliobancario() {
		return foliobancario;
	}

	public void setFoliobancario(String foliobancario) {
		this.foliobancario = foliobancario;
	}

	public byte[] getImgimagen() {
		return imgimagen;
	}

	public void setImgimagen(byte[] imgimagen) {
		this.imgimagen = imgimagen;
	}
	
	

}
