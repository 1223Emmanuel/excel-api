package com.eglobal.bo.api.zip.exporters;

public class LBitacoraEnc {
	  private LBitacoraEnc() {
		    throw new IllegalStateException("Utility class");
		  }
	
	public static final  String NUM= "NUM";
	public static final  String TARJETA = "Tarjeta";
	public static final  String FECHA = "Fecha";
	public static final  String IMPORTE = "Importe";
	public static final  String AUTORIZACION = "Autorizacion";
	public static final  String FOLIO = "Folio";
	public static final  String AFILICIACION = "Afiliacion";
	public static final  String DOCUMENTO = "Documento";

}

