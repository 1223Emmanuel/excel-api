package com.eglobal.bo.api.zip.dto;


public class CImagenesDTO {

	private int idplantilla;     
	private String  aassunto;  
	private String  cmcuerpomensaje;
	private String  ararchivo;
	public int getIdplantilla() {
		return idplantilla;
	}
	public void setIdplantilla(int idplantilla) {
		this.idplantilla = idplantilla;
	}
	public String getAassunto() {
		return aassunto;
	}
	public void setAassunto(String aassunto) {
		this.aassunto = aassunto;
	}
	public String getCmcuerpomensaje() {
		return cmcuerpomensaje;
	}
	public void setCmcuerpomensaje(String cmcuerpomensaje) {
		this.cmcuerpomensaje = cmcuerpomensaje;
	}
	public String getArarchivo() {
		return ararchivo;
	}
	public void setArarchivo(String ararchivo) {
		this.ararchivo = ararchivo;
	}

	
}
