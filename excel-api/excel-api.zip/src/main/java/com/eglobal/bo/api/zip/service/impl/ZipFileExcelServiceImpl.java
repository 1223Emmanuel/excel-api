package com.eglobal.bo.api.zip.service.impl;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.util.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eglobal.bo.api.zip.dto.ParametrosDTO;
import com.eglobal.bo.api.zip.exceptions.RestException;
import com.eglobal.bo.api.zip.service.ExcelService;
import com.eglobal.bo.api.zip.service.HtmlService;
import com.eglobal.bo.api.zip.service.PasswordService;
import com.eglobal.bo.api.zip.service.Pdfservice;
import com.eglobal.bo.api.zip.service.ZipFileExcelService;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.text.DocumentException;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.CompressionLevel;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;

@Service
public class ZipFileExcelServiceImpl implements ZipFileExcelService {
	static final Logger log = LogManager.getLogger(ZipFileExcelServiceImpl.class);
	@Autowired
	private ExcelService excel;

	@Autowired
	private Pdfservice pdf;

	@Autowired
	private HtmlService html;

	@Autowired
	private PasswordService pwd;

	@Transactional
	public String zip(String fileName, ParametrosDTO bcom) throws RestException, IOException, DocumentException {
		try {
			compressWithPassword("C:\\Users\\pinterw27\\Downloads\\Archivos zip\\", bcom);
		} catch (ZipException e) {
			log.error("Error  " + e.getMessage());
		}
		return fileName;
	}

	public char[] pass() throws RestException, IOException {
		// Creacion de Contraseña
		String pass = pwd.obtenerPassword();
		char[] c = pass.toCharArray();
		try (FileWriter fw = new FileWriter("C:\\Users\\pinterw27\\Downloads\\Archivos zip\\password.txt")) {
			fw.write(c);
			fw.flush();
			return c;
		}
	}

	public void compressWithPassword(String sourcePath, ParametrosDTO bcom) throws RestException, IOException {

		ZipFile zipFile = new ZipFile(sourcePath + "Archivos.zip", pass());
		ArrayList<File> fileList = new ArrayList<>();
		// Obtiene Excel Endoder

		String adjunto = excel.obtenerParam(bcom);
		byte[] excelBytes = Base64.getDecoder().decode(adjunto);
		try (FileOutputStream fos = new FileOutputStream("Excel.xls")) {
			fos.write(excelBytes);
			fos.flush();

		}

		// Obtiene PDF Endoder
		ByteArrayInputStream bis = pdf.obtenerParamPdf(bcom);
		byte[] bytes = IOUtils.toByteArray(bis);
		try (FileOutputStream fos1 = new FileOutputStream("tablaPdf.pdf")) {
			fos1.write(bytes);
			fos1.flush();
		}
		// string HTML
		// Convertir HTML
		String prueba = html.obtenerParamhtml(bcom, null);
		File html1 = new File("plantillahtml.html");
		try (FileWriter fooWriter = new FileWriter(html1, false)) { // true to append

			fooWriter.write(prueba);
			fooWriter.flush();
			fooWriter.flush();
		}
		// Convertir de PDF a HTML
		HtmlConverter.convertToPdf(new FileInputStream(html1), new FileOutputStream("plantillapdf.pdf"));

		// Agrega Archicos a zip
		fileList.add(new File("plantillapdf.pdf"));
		fileList.add(new File("plantillahtml.html"));
		fileList.add(new File("tablaPdf.pdf"));
		fileList.add(new File("Excel.xls"));

		ZipParameters zipParameters = new ZipParameters();
		zipParameters.setCompressionMethod(CompressionMethod.DEFLATE);
		zipParameters.setCompressionLevel(CompressionLevel.ULTRA);
		zipParameters.setEncryptFiles(true);
		zipParameters.setEncryptionMethod(EncryptionMethod.AES);
		zipParameters.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);

		zipFile.addFiles(fileList, zipParameters);
	}

}
