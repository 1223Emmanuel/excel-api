package com.eglobal.bo.api.zip.service.impl;

import java.io.ByteArrayInputStream;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.eglobal.bo.api.zip.dto.LBitacoraDTO;
import com.eglobal.bo.api.zip.dto.ParametrosDTO;
import com.eglobal.bo.api.zip.exceptions.RestException;
import com.eglobal.bo.api.zip.repository.dao.ConsultaDAO;
import com.eglobal.bo.api.zip.service.ExportPdfService;
import com.eglobal.bo.api.zip.service.Pdfservice;

@Service
public class PdfServiceImpl implements Pdfservice {

	private Logger logger = LoggerFactory.getLogger(PdfServiceImpl.class);

	@Autowired
	private ExportPdfService pdf;

	@Autowired
	private ConsultaDAO consultadao;

	@Override
	public ByteArrayInputStream obtenerParamPdf(ParametrosDTO com) throws RestException {
		try {
			List<LBitacoraDTO> bitacora = consultadao.obtenerConsulta(com);

			return (pdf.exportaPdf(bitacora));

		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new RestException("100", "Error en PDFServiceImplement");
		}

	}

}
