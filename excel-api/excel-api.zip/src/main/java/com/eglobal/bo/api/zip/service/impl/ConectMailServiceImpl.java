package com.eglobal.bo.api.zip.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringEscapeUtils;
import org.owasp.html.PolicyFactory;
import org.owasp.html.Sanitizers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.eglobal.bo.api.zip.exceptions.RestException;
import com.eglobal.bo.api.zip.exceptions.handle.ResponseRestApi;
import com.eglobal.bo.api.zip.utils.ClientTimeOut;

@Service
public class ConectMailServiceImpl {

	private static Logger logger = LoggerFactory.getLogger(ConectMailServiceImpl.class);
	PolicyFactory policy = Sanitizers.FORMATTING.and(Sanitizers.LINKS);
	@Value("${servicvioMail.url}")
	private String urlMail;

	@SuppressWarnings({ "unchecked", "unused" })
	private ResponseRestApi<String> conectServiceIntegrity(String json, String method) throws RestException {
		logger.info("***INICIA CONEXION Y ENVIO DE DATOS: json[{}]", json);

		HttpHeaders headers = new HttpHeaders();
		ResponseRestApi<String> response = null;
		Map<String, String> parameterMap = new HashMap<>(4);
		parameterMap.put("charset", "utf-8");
		headers.setContentType(new MediaType("application", "json", parameterMap));
		String endpointRuta = this.urlMail + method;
		String jsona = StringEscapeUtils.unescapeHtml3(policy.sanitize(json));
		HttpEntity<String> requestEntity = new HttpEntity<>(jsona, headers);
		response = new RestTemplate(ClientTimeOut.getClientHttpRequestFactory()).postForObject(endpointRuta,
				requestEntity, ResponseRestApi.class);
		String rm = StringEscapeUtils
				.unescapeHtml3(policy.sanitize(String.format("Mensaje: %s", response.getMessage())));
		String rd = StringEscapeUtils
				.unescapeHtml3(policy.sanitize(String.format("Mensaje: %s", response.getDetailMessage())));
		String rh = StringEscapeUtils
				.unescapeHtml3(policy.sanitize(String.format("Mensaje: %s", response.getHttpStatus())));
		logger.info(rm);
		logger.info(rd);
		logger.info(rh);

		if (!(response.getCode() == 200 || response.getCode() == 202)) {
			throw new RestException(
					"CONEXION DE SERVICIO: " + "Error en la respuesta del servicio codigo[" + response.getCode() + "]");
		}

		logger.info("***TERMINA CONEXION Y ENVIO DE DATOS");
		return response;
	}
}
