package com.eglobal.bo.api.zip.service;
import java.io.ByteArrayInputStream;

import org.springframework.stereotype.Service;

import com.eglobal.bo.api.zip.dto.ParametrosDTO;
import com.eglobal.bo.api.zip.exceptions.RestException;
@Service
public interface Pdfservice {



	public ByteArrayInputStream obtenerParamPdf(ParametrosDTO bcom) throws RestException;


}
